<?php
$cacxe = array(  1 => array("ten" => "Mitsubishi Xpander", "hinh" => "mitsubishi.jpg"),
                 2 => array("ten" => "Toyota Vios", "hinh" => "toyota.jpg"),
                 3 => array("ten" => "Vinfast Fadil", "hinh" => "vinfast.jpg"),
                 4 => array("ten" => "Ford Ranger", "hinh" => "ford.jpg"),
                 5 => array("ten" => "KIA Seltos", "hinh" => "kia.jpg"),
                 6 => array("ten" => "Mazda CX-5", "hinh" => "mazda.jpg"),
                 7 => array("ten" => "MG 4 Electric", "hinh" => "mg.jpg"),
                 8 => array("ten" => "XFC Concept", "hinh" => "xfc.png"),
             );
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Vi du ve Mang</title>
	<style>
		.toanbo{
			margin:60px;

		}
		.cacphan{
			float:left;
			border: 5px teal solid;
			margin: 10px;
			border-radius: 10px;
			padding: 5px;
		}

	</style>
</head>
<body>
<center>
<div class="toanbo">
	<h1 align="center">DANH SÁCH XE Ô TÔ 2023</h1>
	<p class="noidung">
	<?php
	    $n = count($cacxe);
	    for($i=1; $i<=$n; $i++)
	    {
	    	echo "<div class='cacphan'>";
	    	echo "<img src='hinh/".$cacxe[$i]["hinh"] ."' width='240' height='200'> ";
	    	echo "<div class='chu'>".$cacxe[$i]["ten"]."</div>";
	    	echo "</div>";
	    }
	?>
		
	</p>
     </div>


</center>
</body>
</html>
